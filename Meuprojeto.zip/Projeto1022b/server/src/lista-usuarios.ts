import mysql, { RowDataPacket } from 'mysql2/promise';
import 'dotenv/config';
type Output = {
    id:number,
    nome:string,
    idade:number,
    cpf:string,
    rg:string,
    endereco: string,
    estado_civil: string
}
interface UsuarioRowDataPacket extends RowDataPacket{
    id:number,
    nome:string,
    idade:number,
    cpf:string,
    rg:string,
    endereco: string,
    estado_civil: string
}
class ListaUsuarios{
    async execute(){
        try{
            const connection = await mysql.createConnection({
                host: process.env.DB_HUST,
                user: process.env.DB_USER,
                database: process.env.DB_BANCO,
              });
               const queryPreparada = await connection.prepare("SELECT * FROM usuarios");
               const queryExecutada = await queryPreparada.execute([])
               const [linhas ,campus] = queryExecutada
               const dados = linhas as UsuarioRowDataPacket[]
               const ListaUsuarios:Output[] = []
               for(let i=0;i<dados.length;i++){
                    const usuario ={
                    id:            dados[i].id,
                    nome:          dados[i].nome,
                    idade:         dados[i].idade,
                    cpf:           dados[i].cpf,
                    rg:            dados[i].rg,
                    endereco:      dados[i].endereco,
                    estado_civil:  dados[i].estado_civil,
                    }
                    ListaUsuarios.push(usuario)
                }
                return ListaUsuarios
        }
        catch(erro:any){ // Se deu Errado
            if(erro.code==='ER_NO_SUCH_TABLE'){
                console.log("ERRO: VOCÊ DEVE CRIAR A TABELA PRODUTOS NO WORKBENCH")
            }else if(erro.code==='ER_PARSE_ERROR'){
                console.log("ERRO: VOCÊ DIGITOU ALGO ERRADO NA QUERY, CONFIRA A ESCRITA, VIRGULAS,NOME DAS COLUNAS E POSIÇÃO DAS PALAVRAS CHAVES.")
            }else if(erro.code==='ECONNREFUSED'){
                console.log("ERRO: FAVOR LIGA O LARAGON!")
            }else if(erro.code==='ER_BAD_DB_ERROR'){
                console.log("ERRO: você não criou o banco de dados 'banco1022B' no workbench!")
            }else{
                console.log(erro)
            }
        }
    }
}
export default ListaUsuarios;