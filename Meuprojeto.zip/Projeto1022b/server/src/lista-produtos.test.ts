import {test,expect,beforeEach} from 'vitest'
import ListaProdutos from './lista-produtos'
import mysql from 'mysql2/promise';
import 'dotenv/config'

beforeEach(async()=>{
    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        database: process.env.DB_BANCO,
    });
    await connection.query("DELETE FROM produtos WHERE id=?",[1])
    await connection.query("INSERT INTO produtos VALUES (?,?,?,?,?)",
        ["1","Iphone","Celular RUIM","5000.50","SEM IMAGEM"])
    await connection.query("DELETE FROM produtos WHERE id=?",[2])
    await connection.query("INSERT INTO produtos VALUES (?,?,?,?,?)",
        ["2","Moto G","Celular Bom","799.99","SEM IMAGEM"])
})

test("Deve listar produtos do banco de dados",async()=>{
    //GIVEN -> DADO ALGO INICIAL
    const listaProdutos = new ListaProdutos()
    const listaPreCadastrada =[
        {
            id: 1,
            nome: 'Iphone',
            descricao: 'Celular RUIM',
            preco: 5000.50,
            imagem: 'SEM IMAGEM'
        },
        {
        id: 2,
        nome: 'Moto G',
        descricao: 'Celular Bom',
        preco: 799.99,
        imagem: 'SEM IMAGEM'
        }
    ]
    //WHEN    -> QUANDO EU EXECUTAR ALGO
    const produtosDoBanco = await listaProdutos.execute()
    //THEN    -> EU ESPERO QUE ISSO ACONTEÇA
    expect(produtosDoBanco).toEqual(listaPreCadastrada)
})