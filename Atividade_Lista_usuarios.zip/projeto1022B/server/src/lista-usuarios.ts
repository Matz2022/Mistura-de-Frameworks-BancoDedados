import mysql, { RowDataPacket } from 'mysql2/promise';
import 'dotenv/config'


type Output = {
    id:number,
    nome:string,
    idade: number,
    cpf: number,
    rg: number,
    endereco: string,
    estado_civil:string
}

interface UsuarioRowDataPacket extends RowDataPacket{
    id:number,
    nome:string,
    idade: string,
    cpf: string,
    rg: string,
    endereco: string,
    estado_civil:string
}



class ListaUsuario{
    

    async execute(){
        try{
            const connection = await mysql.createConnection({
                host: process.env.DB_HOST,
                user: process.env.DB_USER,
                database: process.env.DB_BANCO,
            });
            const queryPreparada1 = await connection.prepare("SELECT * FROM usuarios");
            const queryExecutada1 = await queryPreparada1.execute([])
            const [linhas1 ,campus1] = queryExecutada1
            const dados1 = linhas1 as UsuarioRowDataPacket[]
            const listaUsuarios:Output[] = []
            for(let i=0;i<dados1.length;i++){
                const usuario ={
                    id:         dados1[i].id,
                    nome:       dados1[i].nome,
                    idade:       dados1[i].idade,
                    cpf:       dados1[i].cpf,
                    rg:       dados1[i].rg,
                    endereco:   dados1[i].endereco,
                    estado_civil:   dados1[i].estado_civil,
                    
                }
                listaUsuarios.push(usuario)
            }
            return listaUsuarios   
        }
        catch(erro:any){ // Se deu Errado
            

            if(erro.code==='ER_NO_SUCH_TABLE'){
                console.log("ERRO: VOCÊ DEVE CRIAR A TABELA PRODUTOS NO WORKBENCH")
            }else if(erro.code==='ER_PARSE_ERROR'){
                console.log("ERRO: VOCÊ DIGITOU ALGO ERRADO NA QUERY, CONFIRA A ESCRITA, VIRGULAS,NOME DAS COLUNAS E POSIÇÃO DAS PALAVRAS CHAVES.")
            }else if(erro.code==='ECONNREFUSED'){
                console.log("ERRO: FAVOR LIGA O LARAGON!")
            }else if(erro.code==='ER_BAD_DB_ERROR'){
                console.log("ERRO: você não criou o banco de dados 'banco1022B' no workbench!")
            }else{
                console.log(erro)
            }
        }
    }


}
export default ListaUsuario;