import Cors from 'cors'
import Express , {Request, Response} from 'express';

import ListaProdutos from "./lista-produtos";
import ListaUsuario from "./lista-usuarios";
import InserirProdutos from "./inserir-produtos";
const app = Express();

app.use(Cors())
app.use(Express.json())

app.get("/", (req:Request, res:Response)=>{
    res.send("Respondido.").status(200);                             
})

app.get("/produtos", async (req:Request, res:Response)=>{
    const objListaProdutos = new ListaProdutos();
     //ESSE TIPO DE PRODUTO TEM QUE SER IGUAL AO DO FETCH
    const produtos = await objListaProdutos.execute();
    res.send(produtos).status(200);                             
})
app.post("/produtos", async (req:Request, res:Response)=>{
    //Receber  os dados para inserir no banco.
    //Criar produto recebido pela requisição 
    const {id, nome,descricao,preco,imagem} = req.body
    //ESSE PRODUTO TEM QUE SER IGUAL AO DO FETCH
    const produto ={
        id,
        nome,
        descricao,
        preco,
        imagem
    }
    const objInserirProdutos = new InserirProdutos()
    try{
        const produtoInserido = await objInserirProdutos.execute(produto)
        res.status(201).send(produtoInserido)
    }catch(e){
        res.status(400).send({mensagem: "Não foi possivel cadastrar"});          
    }
                       
})




app.get("/usuarios", async (req:Request, res:Response)=>{
    const objListaUsuarios = new ListaUsuario();
    const usuarios = await objListaUsuarios.execute();
    res.send(usuarios).status(200);                             
})
app.listen(8000, ()=>{
    console.log("Server rodando na porta 8000")
})
