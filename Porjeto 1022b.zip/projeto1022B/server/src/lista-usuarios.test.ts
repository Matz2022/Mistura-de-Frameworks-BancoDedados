import {test, expect, describe} from 'vitest'
import ListaUsuario  from './lista-usuarios'

test("Deve listar os usuarios do banco de dados",async()=>{
    //GIVEN  -> DADO ALGO INICIAL
    const  listaUsuarios = new ListaUsuario()
    const listaPreCadastrada2 =[
        {
        id: 1,
        nome: 'João',
        idade: 18,
        cpf: '036.547.382-10',
        rg: '002.874.325',
        endereco: 'Rua das flores, Bairro dos Planetas, Número 10, Naviraí - MS',
        estado_civil: 'casado'
      
     
      }]
    //WHEN -> QUANDO EU EXECUTAR ALGO

    const produtosDoBanco1 = await  listaUsuarios.execute()
    //THEN  -> EU ESPERO QUE ISSO ACONTEÇA

    expect (produtosDoBanco1).toEqual(listaPreCadastrada2);
})